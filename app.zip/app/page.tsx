// app/page.tsx
export default function Home() {
  const shifts = [
    { date: '2025-06-24', name: '佐藤', time: '09:00-18:00' },
    { date: '2025-06-25', name: '鈴木', time: '10:00-19:00' },
  ]

  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold mb-4">シフト管理システムへようこそ</h1>
      <table className="border w-full text-left">
        <thead>
          <tr>
            <th className="border px-4 py-2">日付</th>
            <th className="border px-4 py-2">名前</th>
            <th className="border px-4 py-2">時間</th>
          </tr>
        </thead>
        <tbody>
          {shifts.map((s, i) => (
            <tr key={i}>
              <td className="border px-4 py-2">{s.date}</td>
              <td className="border px-4 py-2">{s.name}</td>
              <td className="border px-4 py-2">{s.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  )
}
